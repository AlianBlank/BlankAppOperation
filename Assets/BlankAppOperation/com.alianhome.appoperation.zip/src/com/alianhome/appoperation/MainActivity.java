package com.alianhome.appoperation;

import java.util.List;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

public class MainActivity extends UnityPlayerActivity {

	public static boolean OpenAPP(String packageName, String ActivityName,
			String ParamsKey, String ParamsValue) {
		ComponentName componentName = new ComponentName(packageName,
				ActivityName);
		Intent intent = new Intent();
		intent.setComponent(componentName);
		intent.setAction(Intent.ACTION_MAIN);
		intent.putExtra(ParamsKey, ParamsValue);
		if (!intent.hasCategory(Intent.CATEGORY_LAUNCHER)) {
			intent.addCategory(Intent.CATEGORY_LAUNCHER);
		}
		try {
			UnityPlayer.currentActivity.startActivity(intent);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static void InstallAPK(String fileName) {
		InstallApp(fileName);
	}

	private static void InstallApp(String fileName) {
		try {
			String mpath = "file://" + fileName;
			Intent intent = new Intent();
			intent.setAction(Intent.ACTION_VIEW);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

			intent.setDataAndType(Uri.parse(mpath),
					"application/vnd.android.package-archive");
			UnityPlayer.currentActivity.startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean IsAvilible(String packageName) {
		PackageManager packageManager = UnityPlayer.currentActivity
				.getPackageManager();

		List<PackageInfo> pinfo = packageManager.getInstalledPackages(0);
		for (int i = 0; i < pinfo.size(); i++) {
			if (((PackageInfo) pinfo.get(i)).packageName
					.equalsIgnoreCase(packageName)) {
				return true;
			}
		}
		return false;
	}

	public static boolean UninstallAPK(String packageName) {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_DELETE);
		intent.setData(Uri.parse("package:" + packageName));
		try {
			UnityPlayer.currentActivity.startActivity(intent);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static String getAppVersionName(String packageName) {
		PackageInfo packageInfo = null;
		try {
			packageInfo = UnityPlayer.currentActivity.getPackageManager()
					.getPackageInfo(packageName, 0);
			return packageInfo.versionName;
		} catch (android.content.pm.PackageManager.NameNotFoundException e) {
			e.printStackTrace();

			return "0.0";
		}
	}

	public static int getAppVersionCode(String packageName) {
		try {
			PackageInfo packageInfo = UnityPlayer.currentActivity
					.getPackageManager().getPackageInfo(packageName, 0);
			return packageInfo.versionCode;
		} catch (android.content.pm.PackageManager.NameNotFoundException e) {
			e.printStackTrace();

			return 0;
		}
	}
}
